import React from 'react';

function Dashboard() {
  return (
    <div className="container">
      <h2>Dashboard</h2>
      <p>Welcome to your dashboard!</p>
      {/* You can add more user-specific content here */}
    </div>
  );
}

export default Dashboard;
